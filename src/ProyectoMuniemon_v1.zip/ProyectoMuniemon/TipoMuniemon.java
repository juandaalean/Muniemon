package ProyectoMuniemon;

public enum TipoMuniemon {
	AGUA,TIERRA,FUEGO,PLANTA
}
